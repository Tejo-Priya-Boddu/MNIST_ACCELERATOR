// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xmnist_accelerator.h"

extern XMnist_accelerator_Config XMnist_accelerator_ConfigTable[];

#ifdef SDT
XMnist_accelerator_Config *XMnist_accelerator_LookupConfig(UINTPTR BaseAddress) {
	XMnist_accelerator_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XMnist_accelerator_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XMnist_accelerator_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XMnist_accelerator_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMnist_accelerator_Initialize(XMnist_accelerator *InstancePtr, UINTPTR BaseAddress) {
	XMnist_accelerator_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMnist_accelerator_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMnist_accelerator_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XMnist_accelerator_Config *XMnist_accelerator_LookupConfig(u16 DeviceId) {
	XMnist_accelerator_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XMNIST_ACCELERATOR_NUM_INSTANCES; Index++) {
		if (XMnist_accelerator_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XMnist_accelerator_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMnist_accelerator_Initialize(XMnist_accelerator *InstancePtr, u16 DeviceId) {
	XMnist_accelerator_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMnist_accelerator_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMnist_accelerator_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

