// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xmnist_accelerator.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XMnist_accelerator_CfgInitialize(XMnist_accelerator *InstancePtr, XMnist_accelerator_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Ctrl_bus_BaseAddress = ConfigPtr->Ctrl_bus_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XMnist_accelerator_Start(XMnist_accelerator *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMnist_accelerator_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XMNIST_ACCELERATOR_CTRL_BUS_ADDR_AP_CTRL) & 0x80;
    XMnist_accelerator_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XMNIST_ACCELERATOR_CTRL_BUS_ADDR_AP_CTRL, Data | 0x01);
}

u32 XMnist_accelerator_IsDone(XMnist_accelerator *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMnist_accelerator_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XMNIST_ACCELERATOR_CTRL_BUS_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XMnist_accelerator_IsIdle(XMnist_accelerator *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMnist_accelerator_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XMNIST_ACCELERATOR_CTRL_BUS_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XMnist_accelerator_IsReady(XMnist_accelerator *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMnist_accelerator_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XMNIST_ACCELERATOR_CTRL_BUS_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XMnist_accelerator_EnableAutoRestart(XMnist_accelerator *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMnist_accelerator_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XMNIST_ACCELERATOR_CTRL_BUS_ADDR_AP_CTRL, 0x80);
}

void XMnist_accelerator_DisableAutoRestart(XMnist_accelerator *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMnist_accelerator_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XMNIST_ACCELERATOR_CTRL_BUS_ADDR_AP_CTRL, 0);
}

void XMnist_accelerator_Set_input_img(XMnist_accelerator *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMnist_accelerator_WriteReg(InstancePtr->Control_BaseAddress, XMNIST_ACCELERATOR_CONTROL_ADDR_INPUT_IMG_DATA, (u32)(Data));
    XMnist_accelerator_WriteReg(InstancePtr->Control_BaseAddress, XMNIST_ACCELERATOR_CONTROL_ADDR_INPUT_IMG_DATA + 4, (u32)(Data >> 32));
}

u64 XMnist_accelerator_Get_input_img(XMnist_accelerator *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMnist_accelerator_ReadReg(InstancePtr->Control_BaseAddress, XMNIST_ACCELERATOR_CONTROL_ADDR_INPUT_IMG_DATA);
    Data += (u64)XMnist_accelerator_ReadReg(InstancePtr->Control_BaseAddress, XMNIST_ACCELERATOR_CONTROL_ADDR_INPUT_IMG_DATA + 4) << 32;
    return Data;
}

u32 XMnist_accelerator_Get_prediction(XMnist_accelerator *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMnist_accelerator_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XMNIST_ACCELERATOR_CTRL_BUS_ADDR_PREDICTION_DATA);
    return Data;
}

u32 XMnist_accelerator_Get_prediction_vld(XMnist_accelerator *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMnist_accelerator_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XMNIST_ACCELERATOR_CTRL_BUS_ADDR_PREDICTION_CTRL);
    return Data & 0x1;
}

void XMnist_accelerator_InterruptGlobalEnable(XMnist_accelerator *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMnist_accelerator_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XMNIST_ACCELERATOR_CTRL_BUS_ADDR_GIE, 1);
}

void XMnist_accelerator_InterruptGlobalDisable(XMnist_accelerator *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMnist_accelerator_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XMNIST_ACCELERATOR_CTRL_BUS_ADDR_GIE, 0);
}

void XMnist_accelerator_InterruptEnable(XMnist_accelerator *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMnist_accelerator_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XMNIST_ACCELERATOR_CTRL_BUS_ADDR_IER);
    XMnist_accelerator_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XMNIST_ACCELERATOR_CTRL_BUS_ADDR_IER, Register | Mask);
}

void XMnist_accelerator_InterruptDisable(XMnist_accelerator *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMnist_accelerator_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XMNIST_ACCELERATOR_CTRL_BUS_ADDR_IER);
    XMnist_accelerator_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XMNIST_ACCELERATOR_CTRL_BUS_ADDR_IER, Register & (~Mask));
}

void XMnist_accelerator_InterruptClear(XMnist_accelerator *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMnist_accelerator_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XMNIST_ACCELERATOR_CTRL_BUS_ADDR_ISR, Mask);
}

u32 XMnist_accelerator_InterruptGetEnabled(XMnist_accelerator *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMnist_accelerator_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XMNIST_ACCELERATOR_CTRL_BUS_ADDR_IER);
}

u32 XMnist_accelerator_InterruptGetStatus(XMnist_accelerator *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMnist_accelerator_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XMNIST_ACCELERATOR_CTRL_BUS_ADDR_ISR);
}

