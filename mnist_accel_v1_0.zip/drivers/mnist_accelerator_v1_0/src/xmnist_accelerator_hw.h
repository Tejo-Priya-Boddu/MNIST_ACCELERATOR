// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of input_img
//        bit 31~0 - input_img[31:0] (Read/Write)
// 0x14 : Data signal of input_img
//        bit 31~0 - input_img[63:32] (Read/Write)
// 0x18 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XMNIST_ACCELERATOR_CONTROL_ADDR_INPUT_IMG_DATA 0x10
#define XMNIST_ACCELERATOR_CONTROL_BITS_INPUT_IMG_DATA 64

// CTRL_BUS
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of prediction
//        bit 31~0 - prediction[31:0] (Read)
// 0x14 : Control signal of prediction
//        bit 0  - prediction_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XMNIST_ACCELERATOR_CTRL_BUS_ADDR_AP_CTRL         0x00
#define XMNIST_ACCELERATOR_CTRL_BUS_ADDR_GIE             0x04
#define XMNIST_ACCELERATOR_CTRL_BUS_ADDR_IER             0x08
#define XMNIST_ACCELERATOR_CTRL_BUS_ADDR_ISR             0x0c
#define XMNIST_ACCELERATOR_CTRL_BUS_ADDR_PREDICTION_DATA 0x10
#define XMNIST_ACCELERATOR_CTRL_BUS_BITS_PREDICTION_DATA 32
#define XMNIST_ACCELERATOR_CTRL_BUS_ADDR_PREDICTION_CTRL 0x14

