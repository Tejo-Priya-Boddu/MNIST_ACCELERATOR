// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XMNIST_ACCELERATOR_H
#define XMNIST_ACCELERATOR_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xmnist_accelerator_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
    u64 Ctrl_bus_BaseAddress;
} XMnist_accelerator_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Ctrl_bus_BaseAddress;
    u32 IsReady;
} XMnist_accelerator;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XMnist_accelerator_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XMnist_accelerator_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XMnist_accelerator_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XMnist_accelerator_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XMnist_accelerator_Initialize(XMnist_accelerator *InstancePtr, UINTPTR BaseAddress);
XMnist_accelerator_Config* XMnist_accelerator_LookupConfig(UINTPTR BaseAddress);
#else
int XMnist_accelerator_Initialize(XMnist_accelerator *InstancePtr, u16 DeviceId);
XMnist_accelerator_Config* XMnist_accelerator_LookupConfig(u16 DeviceId);
#endif
int XMnist_accelerator_CfgInitialize(XMnist_accelerator *InstancePtr, XMnist_accelerator_Config *ConfigPtr);
#else
int XMnist_accelerator_Initialize(XMnist_accelerator *InstancePtr, const char* InstanceName);
int XMnist_accelerator_Release(XMnist_accelerator *InstancePtr);
#endif

void XMnist_accelerator_Start(XMnist_accelerator *InstancePtr);
u32 XMnist_accelerator_IsDone(XMnist_accelerator *InstancePtr);
u32 XMnist_accelerator_IsIdle(XMnist_accelerator *InstancePtr);
u32 XMnist_accelerator_IsReady(XMnist_accelerator *InstancePtr);
void XMnist_accelerator_EnableAutoRestart(XMnist_accelerator *InstancePtr);
void XMnist_accelerator_DisableAutoRestart(XMnist_accelerator *InstancePtr);

void XMnist_accelerator_Set_input_img(XMnist_accelerator *InstancePtr, u64 Data);
u64 XMnist_accelerator_Get_input_img(XMnist_accelerator *InstancePtr);
u32 XMnist_accelerator_Get_prediction(XMnist_accelerator *InstancePtr);
u32 XMnist_accelerator_Get_prediction_vld(XMnist_accelerator *InstancePtr);

void XMnist_accelerator_InterruptGlobalEnable(XMnist_accelerator *InstancePtr);
void XMnist_accelerator_InterruptGlobalDisable(XMnist_accelerator *InstancePtr);
void XMnist_accelerator_InterruptEnable(XMnist_accelerator *InstancePtr, u32 Mask);
void XMnist_accelerator_InterruptDisable(XMnist_accelerator *InstancePtr, u32 Mask);
void XMnist_accelerator_InterruptClear(XMnist_accelerator *InstancePtr, u32 Mask);
u32 XMnist_accelerator_InterruptGetEnabled(XMnist_accelerator *InstancePtr);
u32 XMnist_accelerator_InterruptGetStatus(XMnist_accelerator *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
